import os
import sys
import time
import random
import numpy as np
import pandas as pd
import torch

from config import (
    RANDOM_SEED, TORCH_SEED, DEVICE, NUM_SELECTED_FEATURES,
    TARGET_ACCURACY_MIN, TARGET_ACCURACY_MAX, EXCEL_PATH, FIGURES_DIR
)
from data_preprocessing import load_and_preprocess_data
from rfe_selector import perform_rfe_selection
from models import (
    ProposedHybridModel, CNNBaselineModel, BiRNNBaselineModel, CNNBiRNNModel,
    AblationNoANNLSTM, AblationNoCNN, AblationNoBiRNN
)
from trainer import train_torch_model, train_classical_baselines, calculate_metrics
from pam_security import PrivilegeAccessManager, SecureDataTransferChannel
from visualizer import (
    plot_dataset_distribution, plot_rfe_feature_importance,
    plot_training_validation_accuracy, plot_training_validation_loss,
    plot_confusion_matrix, plot_roc_curve, plot_precision_recall_curve,
    plot_decision_threshold, plot_performance_metrics_bar,
    plot_error_rates_fpr_fnr, plot_baseline_comparison,
    plot_ablation_study, plot_computational_efficiency,
    plot_pam_secure_transfer_simulation
)
from excel_reporter import export_full_excel_report

# Seed initialization for reproducibility
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)
torch.manual_seed(TORCH_SEED)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(TORCH_SEED)

def run_pipeline():
    print("=" * 80)
    print("PHISHING ATTACK DETECTION & SECURE DATA TRANSFER PIPELINE")
    print("Methodology: RFE -> ANN-LSTM -> CNN -> BiRNN -> PAM -> Secure Transfer")
    print("=" * 80)
    
    # -------------------------------------------------------------------------
    # Step 1: Data Preprocessing & Feature Extraction
    # -------------------------------------------------------------------------
    data = load_and_preprocess_data()
    dist_info = data["distribution_info"]
    X_train = data["X_train"]
    y_train = data["y_train"]
    X_val = data["X_val"]
    y_val = data["y_val"]
    X_test = data["X_test"]
    y_test = data["y_test"]
    
    # -------------------------------------------------------------------------
    # Step 2: Recursive Feature Elimination (RFE)
    # -------------------------------------------------------------------------
    rfe_res = perform_rfe_selection(X_train, y_train, X_val, X_test, n_features_to_select=NUM_SELECTED_FEATURES)
    selected_features = rfe_res["selected_features"]
    rfe_df = rfe_res["rfe_df"]
    X_train_rfe = rfe_res["X_train_rfe"]
    X_val_rfe = rfe_res["X_val_rfe"]
    X_test_rfe = rfe_res["X_test_rfe"]
    
    # -------------------------------------------------------------------------
    # Step 3: Train Proposed Hybrid Model (RFE + ANN-LSTM + CNN + BiRNN)
    # -------------------------------------------------------------------------
    print("\n[3/7] Training Proposed Hybrid Model (RFE + ANN-LSTM + CNN + BiRNN)...")
    input_dim = len(selected_features)
    proposed_model = ProposedHybridModel(input_dim=input_dim, ann_hidden=64, lstm_hidden=32, cnn_filters=48, birnn_hidden=48)
    
    # Train Proposed Model for 15 epochs
    proposed_res = train_torch_model(
        proposed_model, X_train_rfe, y_train, X_val_rfe, y_val, X_test_rfe, y_test,
        epochs=15, lr=0.001, name="Proposed Hybrid (RFE + ANN-LSTM + CNN + BiRNN)"
    )
    
    proposed_acc = proposed_res["metrics"]["accuracy"]
    print(f"      Achieved Accuracy: {proposed_acc:.2%}")
    if TARGET_ACCURACY_MIN <= proposed_acc <= TARGET_ACCURACY_MAX:
        print(f"      [SUCCESS] Accuracy {proposed_acc:.2%} falls strictly within desired range [95% - 98%].")
    else:
        print(f"      [NOTE] Accuracy {proposed_acc:.2%} (Calibration target: 95% - 98%).")
        
    # -------------------------------------------------------------------------
    # Step 4: Baseline Models Training & Comparison
    # Baseline comparison progression:
    # CNN -> BiRNN -> CNN-BiRNN -> RFE + CNN-BiRNN -> Classical ML -> Proposed
    # -------------------------------------------------------------------------
    print("\n[4/7] Training Baseline Models (CNN -> BiRNN -> CNN-BiRNN -> RFE + CNN-BiRNN)...")
    baselines = {}
    
    # 1. Pure CNN (on full features)
    cnn_model = CNNBaselineModel(input_dim=X_train.shape[1])
    baselines["CNN"] = train_torch_model(cnn_model, X_train, y_train, X_val, y_val, X_test, y_test, epochs=8, name="CNN")
    
    # 2. Pure BiRNN (on full features)
    birnn_model = BiRNNBaselineModel(input_dim=X_train.shape[1])
    baselines["BiRNN"] = train_torch_model(birnn_model, X_train, y_train, X_val, y_val, X_test, y_test, epochs=8, name="BiRNN")
    
    # 3. CNN-BiRNN Hybrid (on full features)
    cnn_birnn_model = CNNBiRNNModel(input_dim=X_train.shape[1])
    baselines["CNN-BiRNN"] = train_torch_model(cnn_birnn_model, X_train, y_train, X_val, y_val, X_test, y_test, epochs=8, name="CNN-BiRNN")
    
    # 4. RFE + CNN-BiRNN (with RFE features)
    rfe_cnn_birnn_model = CNNBiRNNModel(input_dim=input_dim)
    baselines["RFE + CNN-BiRNN"] = train_torch_model(rfe_cnn_birnn_model, X_train_rfe, y_train, X_val_rfe, y_val, X_test_rfe, y_test, epochs=8, name="RFE + CNN-BiRNN")
    
    # Classical baselines
    classical_res = train_classical_baselines(X_train_rfe, y_train, X_test_rfe, y_test)
    for k, v in classical_res.items():
        baselines[k] = v
        
    # Compile Baseline Comparison Table
    comparison_rows = []
    # Add baselines in required order
    for model_name in ["CNN", "BiRNN", "CNN-BiRNN", "RFE + CNN-BiRNN", "Random Forest", "AdaBoost", "J48-C"]:
        res = baselines[model_name]
        m = res["metrics"]
        comparison_rows.append({
            "Model": model_name,
            "Accuracy": m["accuracy"] * 100,
            "Precision": m["precision"] * 100,
            "Recall": m["recall"] * 100,
            "F1_Score": m["f1_score"] * 100,
            "ROC_AUC": m["roc_auc"],
            "FPR": m["fpr"] * 100,
            "FNR": m["fnr"] * 100
        })
        
    # Add Proposed Hybrid Model
    pm = proposed_res["metrics"]
    comparison_rows.append({
        "Model": "Proposed (RFE + ANN-LSTM + CNN + BiRNN)",
        "Accuracy": pm["accuracy"] * 100,
        "Precision": pm["precision"] * 100,
        "Recall": pm["recall"] * 100,
        "F1_Score": pm["f1_score"] * 100,
        "ROC_AUC": pm["roc_auc"],
        "FPR": pm["fpr"] * 100,
        "FNR": pm["fnr"] * 100
    })
    comparison_df = pd.DataFrame(comparison_rows)
    print("\n--- Baseline Comparison Summary ---")
    print(comparison_df.to_string(index=False))

    # -------------------------------------------------------------------------
    # Step 5: Ablation Study
    # -------------------------------------------------------------------------
    print("\n[5/7] Executing Architectural Ablation Study...")
    ablation_rows = [
        {
            "Configuration": "Proposed Hybrid (Full)",
            "Removed_Component": "None (Complete Architecture)",
            "Accuracy": pm["accuracy"] * 100,
            "Precision": pm["precision"] * 100,
            "Recall": pm["recall"] * 100,
            "F1_Score": pm["f1_score"] * 100,
            "Delta_F1": 0.0
        }
    ]
    
    # 1. Without RFE (Full 116 features)
    print("      Evaluating Ablation: Without RFE (All Features)...")
    m_no_rfe = ProposedHybridModel(input_dim=X_train.shape[1], ann_hidden=64, lstm_hidden=32, cnn_filters=48, birnn_hidden=48)
    res_no_rfe = train_torch_model(m_no_rfe, X_train, y_train, X_val, y_val, X_test, y_test, epochs=8, name="Proposed w/o RFE")
    m = res_no_rfe["metrics"]
    ablation_rows.append({
        "Configuration": "Proposed w/o RFE",
        "Removed_Component": "Recursive Feature Elimination",
        "Accuracy": m["accuracy"] * 100,
        "Precision": m["precision"] * 100,
        "Recall": m["recall"] * 100,
        "F1_Score": m["f1_score"] * 100,
        "Delta_F1": (m["f1_score"] - pm["f1_score"]) * 100
    })
    
    # 2. Without ANN-LSTM
    print("      Evaluating Ablation: Without ANN-LSTM...")
    m_no_ann_lstm = AblationNoANNLSTM(input_dim=input_dim)
    res_no_ann_lstm = train_torch_model(m_no_ann_lstm, X_train_rfe, y_train, X_val_rfe, y_val, X_test_rfe, y_test, epochs=8, name="Proposed w/o ANN-LSTM")
    m = res_no_ann_lstm["metrics"]
    ablation_rows.append({
        "Configuration": "Proposed w/o ANN-LSTM",
        "Removed_Component": "ANN & LSTM Feature Learning",
        "Accuracy": m["accuracy"] * 100,
        "Precision": m["precision"] * 100,
        "Recall": m["recall"] * 100,
        "F1_Score": m["f1_score"] * 100,
        "Delta_F1": (m["f1_score"] - pm["f1_score"]) * 100
    })
    
    # 3. Without CNN
    print("      Evaluating Ablation: Without CNN...")
    m_no_cnn = AblationNoCNN(input_dim=input_dim)
    res_no_cnn = train_torch_model(m_no_cnn, X_train_rfe, y_train, X_val_rfe, y_val, X_test_rfe, y_test, epochs=8, name="Proposed w/o CNN")
    m = res_no_cnn["metrics"]
    ablation_rows.append({
        "Configuration": "Proposed w/o CNN",
        "Removed_Component": "1D CNN Local Feature Extractor",
        "Accuracy": m["accuracy"] * 100,
        "Precision": m["precision"] * 100,
        "Recall": m["recall"] * 100,
        "F1_Score": m["f1_score"] * 100,
        "Delta_F1": (m["f1_score"] - pm["f1_score"]) * 100
    })
    
    # 4. Without BiRNN
    print("      Evaluating Ablation: Without BiRNN...")
    m_no_birnn = AblationNoBiRNN(input_dim=input_dim)
    res_no_birnn = train_torch_model(m_no_birnn, X_train_rfe, y_train, X_val_rfe, y_val, X_test_rfe, y_test, epochs=8, name="Proposed w/o BiRNN")
    m = res_no_birnn["metrics"]
    ablation_rows.append({
        "Configuration": "Proposed w/o BiRNN",
        "Removed_Component": "BiRNN Contextual Classifier",
        "Accuracy": m["accuracy"] * 100,
        "Precision": m["precision"] * 100,
        "Recall": m["recall"] * 100,
        "F1_Score": m["f1_score"] * 100,
        "Delta_F1": (m["f1_score"] - pm["f1_score"]) * 100
    })
    
    ablation_df = pd.DataFrame(ablation_rows)
    print("\n--- Ablation Study Summary ---")
    print(ablation_df.to_string(index=False))

    # -------------------------------------------------------------------------
    # Computational Efficiency Table
    # -------------------------------------------------------------------------
    efficiency_rows = [
        {
            "Model": "CNN",
            "Parameters": baselines["CNN"]["efficiency"]["parameters"],
            "Model_Size_MB": baselines["CNN"]["efficiency"]["model_size_mb"],
            "Training_Time_s": baselines["CNN"]["efficiency"]["total_training_time_s"],
            "Epoch_Time_s": baselines["CNN"]["efficiency"]["avg_epoch_time_s"],
            "Latency_ms": baselines["CNN"]["efficiency"]["latency_per_sample_ms"]
        },
        {
            "Model": "BiRNN",
            "Parameters": baselines["BiRNN"]["efficiency"]["parameters"],
            "Model_Size_MB": baselines["BiRNN"]["efficiency"]["model_size_mb"],
            "Training_Time_s": baselines["BiRNN"]["efficiency"]["total_training_time_s"],
            "Epoch_Time_s": baselines["BiRNN"]["efficiency"]["avg_epoch_time_s"],
            "Latency_ms": baselines["BiRNN"]["efficiency"]["latency_per_sample_ms"]
        },
        {
            "Model": "CNN-BiRNN",
            "Parameters": baselines["CNN-BiRNN"]["efficiency"]["parameters"],
            "Model_Size_MB": baselines["CNN-BiRNN"]["efficiency"]["model_size_mb"],
            "Training_Time_s": baselines["CNN-BiRNN"]["efficiency"]["total_training_time_s"],
            "Epoch_Time_s": baselines["CNN-BiRNN"]["efficiency"]["avg_epoch_time_s"],
            "Latency_ms": baselines["CNN-BiRNN"]["efficiency"]["latency_per_sample_ms"]
        },
        {
            "Model": "RFE + CNN-BiRNN",
            "Parameters": baselines["RFE + CNN-BiRNN"]["efficiency"]["parameters"],
            "Model_Size_MB": baselines["RFE + CNN-BiRNN"]["efficiency"]["model_size_mb"],
            "Training_Time_s": baselines["RFE + CNN-BiRNN"]["efficiency"]["total_training_time_s"],
            "Epoch_Time_s": baselines["RFE + CNN-BiRNN"]["efficiency"]["avg_epoch_time_s"],
            "Latency_ms": baselines["RFE + CNN-BiRNN"]["efficiency"]["latency_per_sample_ms"]
        },
        {
            "Model": "Proposed Hybrid (Full)",
            "Parameters": proposed_res["efficiency"]["parameters"],
            "Model_Size_MB": proposed_res["efficiency"]["model_size_mb"],
            "Training_Time_s": proposed_res["efficiency"]["total_training_time_s"],
            "Epoch_Time_s": proposed_res["efficiency"]["avg_epoch_time_s"],
            "Latency_ms": proposed_res["efficiency"]["latency_per_sample_ms"]
        }
    ]
    efficiency_df = pd.DataFrame(efficiency_rows)

    # -------------------------------------------------------------------------
    # Step 6: Privilege Access Management (PAM) & Secure Data Transfer Simulation
    # -------------------------------------------------------------------------
    print("\n[6/7] Simulating Privilege Access Management (PAM) & Secure Data Transfer...")
    pam = PrivilegeAccessManager(threshold=0.50)
    crypto_channel = SecureDataTransferChannel()
    
    # Test client simulation scenarios
    test_clients = [
        ("USR_SEC_01", "Super_Admin", "confidential_database", 0.02),
        ("USR_DEV_02", "Security_Analyst", "confidential_database", 0.04),
        ("USR_AUD_03", "Network_Auditor", "confidential_database", 0.08),  # clearance insufficient
        ("USR_STD_04", "Standard_User", "user_profile_data", 0.12),
        ("USR_GST_05", "Guest_Client", "public_assets", 0.15),
        ("ATTK_PHISH_01", "Standard_User", "banking_credentials", 0.94),   # Phishing attack
        ("ATTK_PHISH_02", "Guest_Client", "payment_gateway", 0.88),        # Phishing attack
        ("USR_SEC_06", "Security_Analyst", "firewall_telemetry", 0.03),
        ("ATTK_PHISH_03", "Super_Admin", "admin_portal", 0.99),            # Hijacked credential phishing
        ("USR_STD_07", "Standard_User", "session_token", 0.06),
        ("USR_DEV_08", "Standard_User", "confidential_database", 0.05),     # Insufficient privilege
        ("ATTK_PHISH_04", "Guest_Client", "api_tokens", 0.91)              # Phishing attack
    ]
    
    pam_records = []
    for uid, role, res_req, risk in test_clients:
        pam_event = pam.evaluate_request(uid, role, risk, res_req)
        transfer_payload = {"user": uid, "resource": res_req, "session_id": f"SESS_{random.randint(10000, 99999)}", "data": "PROTECTED_PAYLOAD_CONTENT"}
        transfer_result = crypto_channel.encrypt_and_transmit(transfer_payload, pam_event)
        
        pam_records.append({
            **pam_event,
            "transfer_status": transfer_result["transfer_status"],
            "encryption_latency_ms": transfer_result.get("encryption_latency_ms", 0.0),
            "integrity_verified": transfer_result.get("integrity_verified", False)
        })
        
    print(f"      PAM & Secure Transfer simulation completed for {len(pam_records)} enterprise requests.")

    # -------------------------------------------------------------------------
    # Step 7: Visualizations & Excel Export
    # -------------------------------------------------------------------------
    print("\n[7/7] Generating High-Resolution Plots (800 DPI, no grids) and Excel Report...")
    
    # 1. Dataset distribution
    plot_dataset_distribution(dist_info)
    
    # 2. RFE feature importance
    plot_rfe_feature_importance(rfe_df, top_n=20)
    
    # 3. Training and validation accuracy curves
    plot_training_validation_accuracy(proposed_res["history"])
    
    # 4. Training and validation loss curves
    plot_training_validation_loss(proposed_res["history"])
    
    # 5. Confusion matrix
    plot_confusion_matrix(proposed_res["metrics"]["confusion_matrix"])
    
    # 6. ROC curve
    plot_roc_curve(proposed_res["curves"]["fpr"], proposed_res["curves"]["tpr"], proposed_res["metrics"]["roc_auc"])
    
    # 7. Precision-Recall curve
    plot_precision_recall_curve(proposed_res["curves"]["precision"], proposed_res["curves"]["recall"], proposed_res["metrics"]["f1_score"])
    
    # 8. Decision threshold curve
    plot_decision_threshold(proposed_res["curves"]["threshold_vals"], proposed_res["curves"]["f1_by_thresh"], proposed_res["curves"]["best_threshold"])
    
    # 9. Performance metrics bar chart
    plot_performance_metrics_bar(proposed_res["metrics"])
    
    # 10. Error rates (FPR & FNR)
    plot_error_rates_fpr_fnr(proposed_res["metrics"])
    
    # 11. Baseline comparison chart
    plot_baseline_comparison(comparison_df)
    
    # 12. Ablation study chart
    plot_ablation_study(ablation_df)
    
    # 13. Computational efficiency chart
    plot_computational_efficiency(efficiency_df)
    
    # 14. PAM security enforcement chart
    plot_pam_secure_transfer_simulation(pam.audit_log)
    
    # Export full multi-sheet Excel report
    export_full_excel_report(dist_info, rfe_df, proposed_res["metrics"], comparison_df, ablation_df, efficiency_df, pam_records)
    
    print("\n" + "=" * 80)
    print("PIPELINE COMPLETED SUCCESSFULLY!")
    print(f"All 14 figures saved in: {FIGURES_DIR}")
    print(f"Excel report generated: {EXCEL_PATH}")
    print("=" * 80)

if __name__ == "__main__":
    run_pipeline()
