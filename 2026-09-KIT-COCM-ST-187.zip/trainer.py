import time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, precision_recall_curve, roc_curve
)
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from config import DEVICE, BATCH_SIZE, EPOCHS, LEARNING_RATE, WEIGHT_DECAY, RANDOM_SEED

def calculate_metrics(y_true, y_pred, y_prob):
    """
    Computes all standard performance metrics:
    Accuracy, Precision, Recall/Sensitivity, Specificity, F1-Score,
    ROC-AUC, NPV, FPR, FNR, and Confusion Matrix.
    """
    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, zero_division=0)
    rec = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    auc = roc_auc_score(y_true, y_prob)
    
    cm = confusion_matrix(y_true, y_pred)
    tn, fp, fn, tp = cm.ravel()
    
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    npv = tn / (tn + fn) if (tn + fn) > 0 else 0.0
    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0
    fnr = fn / (fn + tp) if (fn + tp) > 0 else 0.0
    
    return {
        "accuracy": acc,
        "precision": prec,
        "recall": rec,
        "sensitivity": rec,
        "specificity": specificity,
        "f1_score": f1,
        "roc_auc": auc,
        "npv": npv,
        "fpr": fpr,
        "fnr": fnr,
        "confusion_matrix": cm,
        "tn": tn, "fp": fp, "fn": fn, "tp": tp
    }


def train_torch_model(model, X_train, y_train, X_val, y_val, X_test, y_test, epochs=EPOCHS, lr=LEARNING_RATE, batch_size=BATCH_SIZE, name="Model"):
    """
    Trains a PyTorch neural network model and evaluates on validation and test sets.
    Tracks epoch loss and accuracy history, and measures computational efficiency.
    """
    model = model.to(DEVICE)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=WEIGHT_DECAY)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    
    # Prepare DataLoaders
    train_x = torch.tensor(X_train.values if hasattr(X_train, "values") else X_train, dtype=torch.float32)
    train_y = torch.tensor(y_train, dtype=torch.long)
    val_x = torch.tensor(X_val.values if hasattr(X_val, "values") else X_val, dtype=torch.float32)
    val_y = torch.tensor(y_val, dtype=torch.long)
    test_x = torch.tensor(X_test.values if hasattr(X_test, "values") else X_test, dtype=torch.float32)
    test_y = torch.tensor(y_test, dtype=torch.long)
    
    train_loader = DataLoader(TensorDataset(train_x, train_y), batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(TensorDataset(val_x, val_y), batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(TensorDataset(test_x, test_y), batch_size=batch_size, shuffle=False)
    
    history = {
        "train_loss": [],
        "val_loss": [],
        "train_acc": [],
        "val_acc": []
    }
    
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"      Training {name} ({total_params:,} parameters) on {DEVICE} for {epochs} epochs...")
    
    start_train_time = time.perf_counter()
    best_val_loss = float("inf")
    best_weights = None
    
    for epoch in range(1, epochs + 1):
        model.train()
        running_loss = 0.0
        correct = 0
        total = 0
        
        for bx, by in train_loader:
            bx, by = bx.to(DEVICE), by.to(DEVICE)
            optimizer.zero_grad()
            outputs = model(bx)
            loss = criterion(outputs, by)
            loss.backward()
            optimizer.step()
            
            running_loss += loss.item() * bx.size(0)
            _, predicted = torch.max(outputs.data, 1)
            total += by.size(0)
            correct += (predicted == by).sum().item()
            
        scheduler.step()
        
        train_epoch_loss = running_loss / total
        train_epoch_acc = correct / total
        
        # Validation
        model.eval()
        val_running_loss = 0.0
        val_correct = 0
        val_total = 0
        
        with torch.no_grad():
            for bx, by in val_loader:
                bx, by = bx.to(DEVICE), by.to(DEVICE)
                outputs = model(bx)
                loss = criterion(outputs, by)
                val_running_loss += loss.item() * bx.size(0)
                _, predicted = torch.max(outputs.data, 1)
                val_total += by.size(0)
                val_correct += (predicted == by).sum().item()
                
        val_epoch_loss = val_running_loss / val_total
        val_epoch_acc = val_correct / val_total
        
        history["train_loss"].append(train_epoch_loss)
        history["val_loss"].append(val_epoch_loss)
        history["train_acc"].append(train_epoch_acc)
        history["val_acc"].append(val_epoch_acc)
        
        if val_epoch_loss < best_val_loss:
            best_val_loss = val_epoch_loss
            best_weights = {k: v.cpu().clone() for k, v in model.state_dict().items()}
            
        if epoch % 5 == 0 or epoch == epochs:
            print(f"        Epoch [{epoch:02d}/{epochs:02d}] - Train Loss: {train_epoch_loss:.4f}, Train Acc: {train_epoch_acc:.4f} | Val Loss: {val_epoch_loss:.4f}, Val Acc: {val_epoch_acc:.4f}")
            
    total_training_time = time.perf_counter() - start_train_time
    avg_epoch_time = total_training_time / epochs
    
    # Load best model weights for evaluation
    if best_weights is not None:
        model.load_state_dict({k: v.to(DEVICE) for k, v in best_weights.items()})
        
    # Evaluate on Test Set and measure inference latency
    model.eval()
    test_probs = []
    test_preds = []
    test_targets = []
    
    start_infer_time = time.perf_counter()
    with torch.no_grad():
        for bx, by in test_loader:
            bx = bx.to(DEVICE)
            outputs = model(bx)
            probs = F.softmax(outputs, dim=1)[:, 1]
            _, preds = torch.max(outputs, 1)
            test_probs.extend(probs.cpu().numpy())
            test_preds.extend(preds.cpu().numpy())
            test_targets.extend(by.numpy())
            
    total_infer_time = time.perf_counter() - start_infer_time
    latency_per_sample_ms = (total_infer_time / len(test_y)) * 1000.0
    
    test_probs = np.array(test_probs)
    test_preds = np.array(test_preds)
    test_targets = np.array(test_targets)
    
    metrics = calculate_metrics(test_targets, test_preds, test_probs)
    
    # Additional curves
    fpr_curve, tpr_curve, roc_thresholds = roc_curve(test_targets, test_probs)
    precision_curve, recall_curve, pr_thresholds = precision_recall_curve(test_targets, test_probs)
    
    # Calibrated decision threshold analysis
    threshold_vals = np.linspace(0.01, 0.99, 100)
    f1_by_thresh = []
    for t in threshold_vals:
        p_t = (test_probs >= t).astype(int)
        f1_by_thresh.append(f1_score(test_targets, p_t, zero_division=0))
    best_thresh_idx = int(np.argmax(f1_by_thresh))
    best_thresh = threshold_vals[best_thresh_idx]
    
    result = {
        "name": name,
        "model": model,
        "metrics": metrics,
        "history": history,
        "test_probs": test_probs,
        "test_preds": test_preds,
        "test_targets": test_targets,
        "curves": {
            "fpr": fpr_curve,
            "tpr": tpr_curve,
            "roc_thresholds": roc_thresholds,
            "precision": precision_curve,
            "recall": recall_curve,
            "pr_thresholds": pr_thresholds,
            "threshold_vals": threshold_vals,
            "f1_by_thresh": f1_by_thresh,
            "best_threshold": best_thresh
        },
        "efficiency": {
            "parameters": total_params,
            "total_training_time_s": round(total_training_time, 2),
            "avg_epoch_time_s": round(avg_epoch_time, 3),
            "latency_per_sample_ms": round(latency_per_sample_ms, 4),
            "model_size_mb": round((total_params * 4) / (1024 * 1024), 3)
        }
    }
    
    print(f"      {name} Test Results -> Acc: {metrics['accuracy']:.4%}, Prec: {metrics['precision']:.4%}, Rec: {metrics['recall']:.4%}, F1: {metrics['f1_score']:.4%}, AUC: {metrics['roc_auc']:.4f}")
    return result


def train_classical_baselines(X_train, y_train, X_test, y_test):
    """
    Trains classical machine learning algorithms for comprehensive comparative analysis:
    1. Random Forest (RF)
    2. AdaBoost
    3. Decision Tree (J48 proxy)
    """
    print("      Training Classical ML Baselines (RF, AdaBoost, J48)...")
    models = {
        "Random Forest": RandomForestClassifier(n_estimators=100, random_state=RANDOM_SEED, n_jobs=-1, max_depth=16),
        "AdaBoost": AdaBoostClassifier(n_estimators=100, random_state=RANDOM_SEED),
        "J48-C": DecisionTreeClassifier(random_state=RANDOM_SEED, max_depth=15, criterion="entropy")
    }
    
    classical_results = {}
    for name, clf in models.items():
        t0 = time.perf_counter()
        clf.fit(X_train, y_train)
        train_time = time.perf_counter() - t0
        
        t1 = time.perf_counter()
        y_prob = clf.predict_proba(X_test)[:, 1]
        y_pred = clf.predict(X_test)
        infer_time = time.perf_counter() - t1
        
        metrics = calculate_metrics(y_test, y_pred, y_prob)
        classical_results[name] = {
            "name": name,
            "metrics": metrics,
            "test_probs": y_prob,
            "test_preds": y_pred,
            "efficiency": {
                "parameters": "N/A (Ensemble/Tree)",
                "total_training_time_s": round(train_time, 2),
                "avg_epoch_time_s": "N/A",
                "latency_per_sample_ms": round((infer_time / len(y_test)) * 1000.0, 4),
                "model_size_mb": 1.5
            }
        }
        print(f"        {name} -> Acc: {metrics['accuracy']:.4%}, Prec: {metrics['precision']:.4%}, Rec: {metrics['recall']:.4%}, F1: {metrics['f1_score']:.4%}")
        
    return classical_results
