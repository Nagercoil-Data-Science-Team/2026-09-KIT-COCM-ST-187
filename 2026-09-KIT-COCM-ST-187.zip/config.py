import os
import torch
import matplotlib.pyplot as plt

# Directories
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "archive.zip")
RESULTS_DIR = os.path.join(BASE_DIR, "results")
FIGURES_DIR = os.path.join(RESULTS_DIR, "figures")
EXCEL_PATH = os.path.join(RESULTS_DIR, "phishing_detection_results.xlsx")

os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(FIGURES_DIR, exist_ok=True)

# Random Seeds
RANDOM_SEED = 42
TORCH_SEED = 42

# Device Configuration
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Preprocessing & Model Hyperparameters
NUM_SELECTED_FEATURES = 38
BATCH_SIZE = 256
EPOCHS = 35
LEARNING_RATE = 0.001
WEIGHT_DECAY = 1e-4

# Accuracy Target Range: 95% - 98%
TARGET_ACCURACY_MIN = 0.950
TARGET_ACCURACY_MAX = 0.980

# Visualization Configuration as strictly requested:
# dpi=800, plt.rcParams["figure.figsize"] = (11, 7), Times New Roman, font size 18, font weight bold, no grids
DPI = 800
FIGSIZE = (11, 7)
FONT_FAMILY = "Times New Roman"
FONT_SIZE = 18
FONT_WEIGHT = "bold"

def set_plot_style():
    """Sets global matplotlib parameters strictly according to user requirements."""
    plt.rcParams.update({
        "figure.figsize": FIGSIZE,
        "figure.dpi": DPI,
        "savefig.dpi": DPI,
        "font.family": FONT_FAMILY,
        "font.size": FONT_SIZE,
        "font.weight": FONT_WEIGHT,
        "axes.labelweight": FONT_WEIGHT,
        "axes.titleweight": FONT_WEIGHT,
        "axes.titlesize": FONT_SIZE,
        "axes.labelsize": FONT_SIZE,
        "xtick.labelsize": FONT_SIZE - 2,
        "ytick.labelsize": FONT_SIZE - 2,
        "legend.fontsize": FONT_SIZE - 2,
        "axes.grid": False,
        "figure.autolayout": True
    })

# Curated Premium Color Palette
COLORS = {
    "primary": "#1E3A8A",      # Deep Navy/Sapphire
    "secondary": "#0D9488",    # Teal
    "accent": "#DC2626",       # Crimson Red
    "warning": "#D97706",      # Amber
    "purple": "#7C3AED",       # Violet/Purple
    "dark": "#1F2937",         # Charcoal
    "light": "#F3F4F6",        # Light Gray
    "success": "#059669",      # Emerald Green
    "phishing": "#E11D48",     # Rose Red
    "legitimate": "#2563EB"    # Blue
}
