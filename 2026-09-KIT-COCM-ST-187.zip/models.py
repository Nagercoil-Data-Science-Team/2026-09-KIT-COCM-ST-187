import torch
import torch.nn as nn
import torch.nn.functional as F

class ProposedHybridModel(nn.Module):
    """
    Proposed Architecture:
    RFE Features -> ANN-LSTM Feature Learning -> CNN Feature Extraction -> BiRNN Classification
    
    1. ANN Branch: Learns static non-linear transformations across features.
    2. LSTM Branch: Captures sequential dependencies across structured feature groups.
    3. Fusion: Concatenates ANN and LSTM representations: F = [A_static; h_T].
    4. CNN Layer: 1D convolutions extract localized high-level pattern representations.
    5. BiRNN Layer: Bidirectional recurrent processing captures forward & backward temporal dynamics.
    6. Classifier Head: Fully-connected projection predicting Legitimate vs Phishing.
    """
    def __init__(self, input_dim, ann_hidden=64, lstm_hidden=32, cnn_filters=64, birnn_hidden=48, num_classes=2, dropout=0.25):
        super().__init__()
        self.input_dim = input_dim
        
        # 1. ANN Feature Learning Branch
        self.ann = nn.Sequential(
            nn.Linear(input_dim, ann_hidden),
            nn.BatchNorm1d(ann_hidden),
            nn.LeakyReLU(0.1),
            nn.Dropout(dropout),
            nn.Linear(ann_hidden, ann_hidden // 2),
            nn.BatchNorm1d(ann_hidden // 2),
            nn.LeakyReLU(0.1)
        )
        
        # 2. LSTM Sequential Feature Learning Branch
        # Treat input features as a sequence of feature groups
        # Reshape input_dim -> (batch, seq_len=input_dim, 1)
        self.lstm = nn.LSTM(
            input_size=1,
            hidden_size=lstm_hidden,
            num_layers=1,
            batch_first=True
        )
        
        # Fusion dimensionality: ANN output + LSTM final hidden state
        fused_dim = (ann_hidden // 2) + lstm_hidden  # e.g., 32 + 32 = 64
        
        # 3. CNN Feature Extraction Stage
        # Reshape fused features to (batch, channels=1, length=fused_dim)
        self.conv1 = nn.Conv1d(in_channels=1, out_channels=cnn_filters, kernel_size=3, padding=1)
        self.bn_conv1 = nn.BatchNorm1d(cnn_filters)
        self.pool1 = nn.MaxPool1d(kernel_size=2)
        
        self.conv2 = nn.Conv1d(in_channels=cnn_filters, out_channels=cnn_filters * 2, kernel_size=3, padding=1)
        self.bn_conv2 = nn.BatchNorm1d(cnn_filters * 2)
        self.pool2 = nn.MaxPool1d(kernel_size=2)
        
        # 4. BiRNN Classification Stage
        # BiRNN processes CNN feature sequence along time dimension
        # Input to BiRNN: (batch, seq_len, input_size = cnn_filters * 2)
        self.birnn = nn.GRU(
            input_size=cnn_filters * 2,
            hidden_size=birnn_hidden,
            num_layers=1,
            batch_first=True,
            bidirectional=True
        )
        
        # 5. Classifier Head
        birnn_out_dim = birnn_hidden * 2  # Bidirectional
        self.classifier = nn.Sequential(
            nn.Linear(birnn_out_dim, 32),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(32, num_classes)
        )
        
    def forward(self, x):
        # x shape: (batch, input_dim)
        batch_size = x.size(0)
        
        # --- 1. ANN Feature Learning ---
        ann_out = self.ann(x)  # (batch, ann_hidden // 2)
        
        # --- 2. LSTM Sequential Learning ---
        x_seq = x.unsqueeze(-1)  # (batch, input_dim, 1)
        lstm_out, (hn, cn) = self.lstm(x_seq)
        lstm_feat = hn[-1]  # (batch, lstm_hidden)
        
        # --- 3. Concatenation of Features ---
        fused = torch.cat([ann_out, lstm_feat], dim=1)  # (batch, fused_dim)
        
        # --- 4. CNN Feature Extraction ---
        cnn_in = fused.unsqueeze(1)  # (batch, 1, fused_dim)
        c1 = self.pool1(F.relu(self.bn_conv1(self.conv1(cnn_in))))
        c2 = self.pool2(F.relu(self.bn_conv2(self.conv2(c1))))  # (batch, cnn_filters*2, seq_len)
        
        # --- 5. BiRNN Sequential Context Learning ---
        birnn_in = c2.permute(0, 2, 1)  # (batch, seq_len, channels)
        birnn_out, _ = self.birnn(birnn_in)  # (batch, seq_len, birnn_hidden*2)
        h_context = torch.mean(birnn_out, dim=1)  # Global pooling over sequence
        
        # --- 6. Classification Head ---
        logits = self.classifier(h_context)
        return logits


class CNNBaselineModel(nn.Module):
    """Pure CNN Baseline for Phishing Classification"""
    def __init__(self, input_dim, num_classes=2, dropout=0.25):
        super().__init__()
        self.conv1 = nn.Conv1d(1, 32, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm1d(32)
        self.pool1 = nn.MaxPool1d(2)
        self.conv2 = nn.Conv1d(32, 64, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm1d(64)
        self.pool2 = nn.AdaptiveAvgPool1d(4)
        self.classifier = nn.Sequential(
            nn.Linear(64 * 4, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, num_classes)
        )
        
    def forward(self, x):
        x = x.unsqueeze(1)
        x = self.pool1(F.relu(self.bn1(self.conv1(x))))
        x = self.pool2(F.relu(self.bn2(self.conv2(x))))
        x = x.view(x.size(0), -1)
        return self.classifier(x)


class BiRNNBaselineModel(nn.Module):
    """Pure Bidirectional RNN Baseline"""
    def __init__(self, input_dim, hidden_size=64, num_classes=2, dropout=0.25):
        super().__init__()
        self.birnn = nn.GRU(1, hidden_size, num_layers=1, batch_first=True, bidirectional=True)
        self.classifier = nn.Sequential(
            nn.Linear(hidden_size * 2, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, num_classes)
        )
        
    def forward(self, x):
        x = x.unsqueeze(-1)  # (batch, input_dim, 1)
        out, _ = self.birnn(x)
        h_context = torch.mean(out, dim=1)
        return self.classifier(h_context)


class CNNBiRNNModel(nn.Module):
    """CNN-BiRNN Hybrid Baseline (Without ANN-LSTM)"""
    def __init__(self, input_dim, num_classes=2, dropout=0.25):
        super().__init__()
        self.conv1 = nn.Conv1d(1, 48, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm1d(48)
        self.pool1 = nn.MaxPool1d(2)
        self.birnn = nn.GRU(48, 48, num_layers=1, batch_first=True, bidirectional=True)
        self.classifier = nn.Sequential(
            nn.Linear(48 * 2, 32),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(32, num_classes)
        )
        
    def forward(self, x):
        x = x.unsqueeze(1)
        c = self.pool1(F.relu(self.bn1(self.conv1(x))))
        r_in = c.permute(0, 2, 1)
        r_out, _ = self.birnn(r_in)
        h = torch.mean(r_out, dim=1)
        return self.classifier(h)


# --- Ablation Variations ---

class AblationNoANNLSTM(nn.Module):
    """Ablation: Without ANN-LSTM feature learning (RFE -> CNN -> BiRNN)"""
    def __init__(self, input_dim, num_classes=2, dropout=0.25):
        super().__init__()
        self.conv1 = nn.Conv1d(1, 64, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm1d(64)
        self.pool1 = nn.MaxPool1d(2)
        self.birnn = nn.GRU(64, 48, num_layers=1, batch_first=True, bidirectional=True)
        self.classifier = nn.Sequential(
            nn.Linear(48 * 2, 32),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(32, num_classes)
        )
    def forward(self, x):
        x = x.unsqueeze(1)
        c = self.pool1(F.relu(self.bn1(self.conv1(x))))
        r_in = c.permute(0, 2, 1)
        r_out, _ = self.birnn(r_in)
        return self.classifier(torch.mean(r_out, dim=1))


class AblationNoCNN(nn.Module):
    """Ablation: Without CNN local feature extraction (ANN-LSTM -> BiRNN)"""
    def __init__(self, input_dim, num_classes=2, dropout=0.25):
        super().__init__()
        self.ann = nn.Sequential(
            nn.Linear(input_dim, 32),
            nn.BatchNorm1d(32),
            nn.ReLU()
        )
        self.lstm = nn.LSTM(1, 32, num_layers=1, batch_first=True)
        self.birnn = nn.GRU(64, 48, num_layers=1, batch_first=True, bidirectional=True)
        self.classifier = nn.Sequential(
            nn.Linear(48 * 2, 32),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(32, num_classes)
        )
    def forward(self, x):
        ann_out = self.ann(x)
        x_seq = x.unsqueeze(-1)
        _, (hn, _) = self.lstm(x_seq)
        fused = torch.cat([ann_out, hn[-1]], dim=1)
        birnn_in = fused.unsqueeze(1)
        birnn_out, _ = self.birnn(birnn_in)
        return self.classifier(torch.mean(birnn_out, dim=1))


class AblationNoBiRNN(nn.Module):
    """Ablation: Without BiRNN contextual learning (ANN-LSTM -> CNN -> Classifier)"""
    def __init__(self, input_dim, num_classes=2, dropout=0.25):
        super().__init__()
        self.ann = nn.Sequential(
            nn.Linear(input_dim, 32),
            nn.BatchNorm1d(32),
            nn.ReLU()
        )
        self.lstm = nn.LSTM(1, 32, num_layers=1, batch_first=True)
        self.conv1 = nn.Conv1d(1, 64, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm1d(64)
        self.pool1 = nn.AdaptiveAvgPool1d(1)
        self.classifier = nn.Sequential(
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(32, num_classes)
        )
    def forward(self, x):
        ann_out = self.ann(x)
        x_seq = x.unsqueeze(-1)
        _, (hn, _) = self.lstm(x_seq)
        fused = torch.cat([ann_out, hn[-1]], dim=1).unsqueeze(1)
        c = self.pool1(F.relu(self.bn1(self.conv1(fused)))).squeeze(-1)
        return self.classifier(c)
