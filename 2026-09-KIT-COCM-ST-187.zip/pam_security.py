import os
import time
import json
import base64
import hashlib
import hmac
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

class PrivilegeAccessManager:
    """
    Privilege Access Management (PAM) System:
    - User/Client Identity Verification
    - Role-Based Access Control (RBAC)
    - Phishing Risk Aggregator: D = sum(f_d(I_i, P_j))
    - Alert Generation: A = 1 if D >= T, 0 otherwise
    - Unauthorized access restriction and SIEM security event auditing
    """
    def __init__(self, threshold=0.50):
        self.threshold = threshold
        self.audit_log = []
        
        # Defined Role Privileges
        self.roles_permissions = {
            "Super_Admin": {"clearance": 5, "can_access_confidential": True, "can_transfer_data": True},
            "Security_Analyst": {"clearance": 4, "can_access_confidential": True, "can_transfer_data": True},
            "Network_Auditor": {"clearance": 3, "can_access_confidential": False, "can_transfer_data": True},
            "Standard_User": {"clearance": 2, "can_access_confidential": False, "can_transfer_data": True},
            "Guest_Client": {"clearance": 1, "can_access_confidential": False, "can_transfer_data": False}
        }
        
    def evaluate_request(self, user_id, role, phishing_probability, resource_requested):
        """
        Evaluates a client request through the combined PAM and Phishing Detection pipeline.
        """
        role_info = self.roles_permissions.get(role, {"clearance": 0, "can_access_confidential": False, "can_transfer_data": False})
        
        # Risk score calculation based on detection function
        d_risk = float(phishing_probability)
        
        # Equation (29): Alert generation if D >= Threshold
        alert = 1 if d_risk >= self.threshold else 0
        
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        
        if alert == 1:
            decision = "BLOCKED_PHISHING_ATTACK"
            status = "ACCESS_DENIED"
            action = "Trigger Security Alert, Terminate Session, Quarantine IP, Notify SOC"
        else:
            # Check privilege permissions
            if resource_requested == "confidential_database" and not role_info["can_access_confidential"]:
                decision = "BLOCKED_INSUFFICIENT_PRIVILEGE"
                status = "ACCESS_DENIED"
                action = "Log Privilege Violation, Deny Access"
            elif not role_info["can_transfer_data"]:
                decision = "BLOCKED_UNAUTHORIZED_ROLE"
                status = "ACCESS_DENIED"
                action = "Deny Data Transfer, Restrict to Read-Only Public"
            else:
                decision = "APPROVED_SECURE_TRANSFER"
                status = "ACCESS_GRANTED"
                action = "Authorize Session, Initialize Cryptographic Tunnel"
                
        event = {
            "timestamp": timestamp,
            "user_id": user_id,
            "role": role,
            "clearance_level": role_info["clearance"],
            "resource": resource_requested,
            "phishing_risk_score": round(d_risk, 4),
            "threshold": self.threshold,
            "alert_signal": alert,
            "decision": decision,
            "status": status,
            "security_action": action
        }
        self.audit_log.append(event)
        return event


class SecureDataTransferChannel:
    """
    Secure Cryptographic Data Transfer Channel:
    - Encrypts payload using authenticated AES-256-GCM.
    - Generates SHA-256 HMAC for tamper verification.
    - Ensures confidential transmission only when PAM approval is granted.
    """
    def __init__(self):
        # Generate 256-bit master key
        self.master_key = AESGCM.generate_key(bit_length=256)
        self.aesgcm = AESGCM(self.master_key)
        self.hmac_secret = os.urandom(32)
        
    def encrypt_and_transmit(self, payload_dict, pam_event):
        """
        Executes secure data encryption and transmission if PAM status is ACCESS_GRANTED.
        """
        if pam_event["status"] != "ACCESS_GRANTED":
            return {
                "transfer_status": "ABORTED_BY_PAM",
                "ciphertext": None,
                "nonce": None,
                "hmac_digest": None,
                "bytes_transferred": 0,
                "integrity_verified": False,
                "message": f"Transfer rejected: {pam_event['decision']}"
            }
            
        start_time = time.perf_counter()
        raw_data = json.dumps(payload_dict).encode("utf-8")
        nonce = os.urandom(12)  # Standard 96-bit nonce for GCM
        
        # AES-256-GCM authenticated encryption
        ciphertext = self.aesgcm.encrypt(nonce, raw_data, associated_data=pam_event["user_id"].encode("utf-8"))
        
        # HMAC-SHA256 signature
        signature = hmac.new(self.hmac_secret, ciphertext, hashlib.sha256).hexdigest()
        elapsed_ms = (time.perf_counter() - start_time) * 1000.0
        
        return {
            "transfer_status": "SUCCESS_ENCRYPTED",
            "ciphertext": base64.b64encode(ciphertext).decode("ascii")[:32] + "...",
            "nonce": base64.b64encode(nonce).decode("ascii"),
            "hmac_digest": signature[:24] + "...",
            "bytes_transferred": len(ciphertext),
            "encryption_latency_ms": round(elapsed_ms, 3),
            "integrity_verified": True,
            "message": "Data securely encrypted and transferred over authenticated channel"
        }
        
    def decrypt_payload(self, nonce_b64, ciphertext_b64, user_id):
        """Decrypts and verifies authentication tag."""
        nonce = base64.b64decode(nonce_b64)
        ciphertext = base64.b64decode(ciphertext_b64)
        decrypted = self.aesgcm.decrypt(nonce, ciphertext, associated_data=user_id.encode("utf-8"))
        return json.loads(decrypted.decode("utf-8"))
