import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import pandas as pd
from config import EXCEL_PATH

# Formatting Styles
HEADER_FILL = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
HEADER_FONT = Font(name="Times New Roman", size=11, bold=True, color="FFFFFF")
SUBHEADER_FILL = PatternFill(start_color="3B82F6", end_color="3B82F6", fill_type="solid")
SUBHEADER_FONT = Font(name="Times New Roman", size=10, bold=True, color="FFFFFF")

REGULAR_FONT = Font(name="Times New Roman", size=10)
BOLD_FONT = Font(name="Times New Roman", size=10, bold=True)
TITLE_FONT = Font(name="Times New Roman", size=14, bold=True, color="1E3A8A")

THIN_BORDER = Border(
    left=Side(style="thin", color="D1D5DB"),
    right=Side(style="thin", color="D1D5DB"),
    top=Side(style="thin", color="D1D5DB"),
    bottom=Side(style="thin", color="D1D5DB")
)

ALT_FILL = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid")
SUCCESS_FILL = PatternFill(start_color="DCFCE7", end_color="DCFCE7", fill_type="solid")
DANGER_FILL = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")

def apply_header_style(cell):
    cell.fill = HEADER_FILL
    cell.font = HEADER_FONT
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = THIN_BORDER

def auto_fit_columns(ws, min_width=12):
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            val_str = str(cell.value or '')
            if len(val_str) > max_len:
                max_len = len(val_str)
        ws.column_dimensions[col_letter].width = max(max_len + 4, min_width)


def export_full_excel_report(dist_info, rfe_df, proposed_metrics, baseline_df, ablation_df, efficiency_df, pam_records):
    """
    Exports a comprehensive, publication-ready multi-sheet Excel workbook.
    """
    wb = openpyxl.Workbook()
    # Remove default sheet
    wb.remove(wb.active)
    
    # -------------------------------------------------------------
    # Sheet 1: Dataset Distribution
    # -------------------------------------------------------------
    ws1 = wb.create_sheet(title="Dataset Distribution")
    ws1["A1"] = "PHISHING WEBSITES DATASET DISTRIBUTION & SPLIT SUMMARY"
    ws1["A1"].font = TITLE_FONT
    
    headers1 = ["Partition / Split", "Legitimate (0)", "Phishing (1)", "Total Samples", "Legitimate Ratio (%)", "Phishing Ratio (%)"]
    ws1.append([])
    ws1.append(headers1)
    for col_num in range(1, len(headers1) + 1):
        apply_header_style(ws1.cell(row=3, column=col_num))
        
    data1 = [
        ["Training Set (70%)", dist_info["train_legitimate"], dist_info["train_phishing"], dist_info["train_samples"],
         f"{dist_info['train_legitimate']/dist_info['train_samples']*100:.2f}%", f"{dist_info['train_phishing']/dist_info['train_samples']*100:.2f}%"],
        ["Validation Set (10%)", dist_info["val_legitimate"], dist_info["val_phishing"], dist_info["val_samples"],
         f"{dist_info['val_legitimate']/dist_info['val_samples']*100:.2f}%", f"{dist_info['val_phishing']/dist_info['val_samples']*100:.2f}%"],
        ["Testing Set (20%)", dist_info["test_legitimate"], dist_info["test_phishing"], dist_info["test_samples"],
         f"{dist_info['test_legitimate']/dist_info['test_samples']*100:.2f}%", f"{dist_info['test_phishing']/dist_info['test_samples']*100:.2f}%"],
        ["Total Clean Dataset", dist_info["legitimate_total"], dist_info["phishing_total"], dist_info["clean_samples"],
         f"{dist_info['legitimate_total']/dist_info['clean_samples']*100:.2f}%", f"{dist_info['phishing_total']/dist_info['clean_samples']*100:.2f}%"],
        ["Original Raw Records", "N/A", "N/A", dist_info["initial_samples"], "Duplicates Removed:", dist_info["duplicates_removed"]]
    ]
    
    for row_idx, row_data in enumerate(data1, start=4):
        ws1.append(row_data)
        for col_idx in range(1, len(row_data) + 1):
            c = ws1.cell(row=row_idx, column=col_idx)
            c.font = BOLD_FONT if row_idx in [7, 8] else REGULAR_FONT
            c.alignment = Alignment(horizontal="center", vertical="center")
            c.border = THIN_BORDER
            if row_idx % 2 == 1:
                c.fill = ALT_FILL
    auto_fit_columns(ws1)

    # -------------------------------------------------------------
    # Sheet 2: Preprocessing & RFE Results
    # -------------------------------------------------------------
    ws2 = wb.create_sheet(title="Preprocessing & RFE Results")
    ws2["A1"] = "RECURSIVE FEATURE ELIMINATION (RFE) SELECTION RANKINGS"
    ws2["A1"].font = TITLE_FONT
    
    headers2 = ["Rank", "Feature Name", "RFE Selected", "Importance Score", "Preprocessing Action"]
    ws2.append([])
    ws2.append(headers2)
    for col_num in range(1, len(headers2) + 1):
        apply_header_style(ws2.cell(row=3, column=col_num))
        
    for r_idx, row in rfe_df.iterrows():
        action = "StandardScaler + Retained" if row["Selected"] else "Pruned (Eliminated)"
        row_data = [int(row["Rank"]), row["Feature"], "YES" if row["Selected"] else "NO", round(float(row["Importance"]), 6), action]
        ws2.append(row_data)
        current_row = ws2.max_row
        for c_idx in range(1, len(row_data) + 1):
            c = ws2.cell(row=current_row, column=c_idx)
            c.font = REGULAR_FONT
            c.alignment = Alignment(horizontal="center", vertical="center")
            c.border = THIN_BORDER
            if row["Selected"]:
                c.fill = SUCCESS_FILL
            elif current_row % 2 == 1:
                c.fill = ALT_FILL
    auto_fit_columns(ws2)

    # -------------------------------------------------------------
    # Sheet 3: Proposed Model Performance
    # -------------------------------------------------------------
    ws3 = wb.create_sheet(title="Proposed Model Performance")
    ws3["A1"] = "PROPOSED HYBRID MODEL PERFORMANCE EVALUATION"
    ws3["A1"].font = TITLE_FONT
    
    headers3 = ["S. No", "Metric", "Formula / Description", "Value (%) / Count", "Benchmark Standard"]
    ws3.append([])
    ws3.append(headers3)
    for col_num in range(1, len(headers3) + 1):
        apply_header_style(ws3.cell(row=3, column=col_num))
        
    data3 = [
        [1, "Accuracy", "(TP + TN) / Total", f"{proposed_metrics['accuracy']*100:.4f}%", "Target: 95% - 98%"],
        [2, "Precision", "TP / (TP + FP)", f"{proposed_metrics['precision']*100:.4f}%", "High Precision"],
        [3, "Sensitivity / Recall", "TP / (TP + FN)", f"{proposed_metrics['sensitivity']*100:.4f}%", "High Sensitivity"],
        [4, "Specificity", "TN / (TN + FP)", f"{proposed_metrics['specificity']*100:.4f}%", "High Specificity"],
        [5, "F-Measure (F1-Score)", "2 * (Prec * Rec) / (Prec + Rec)", f"{proposed_metrics['f1_score']*100:.4f}%", "Balanced Metric"],
        [6, "ROC-AUC", "Area Under ROC Curve", f"{proposed_metrics['roc_auc']:.4f}", "Excellent Discrimination"],
        [7, "Negative Predictive Value (NPV)", "TN / (TN + FN)", f"{proposed_metrics['npv']*100:.4f}%", "Reliable Negative ID"],
        [8, "False Positive Rate (FPR)", "FP / (FP + TN)", f"{proposed_metrics['fpr']*100:.4f}%", "Target: < 2%"],
        [9, "False Negative Rate (FNR)", "FN / (FN + TP)", f"{proposed_metrics['fnr']*100:.4f}%", "Target: < 3%"],
        [10, "True Positives (TP)", "Phishing correctly detected", proposed_metrics['tp'], "Ground Truth Match"],
        [11, "True Negatives (TN)", "Legitimate correctly detected", proposed_metrics['tn'], "Ground Truth Match"],
        [12, "False Positives (FP)", "Legitimate falsely flagged", proposed_metrics['fp'], "Type I Error"],
        [13, "False Negatives (FN)", "Phishing falsely missed", proposed_metrics['fn'], "Type II Error"]
    ]
    
    for row_idx, row_data in enumerate(data3, start=4):
        ws3.append(row_data)
        for col_idx in range(1, len(row_data) + 1):
            c = ws3.cell(row=row_idx, column=col_idx)
            c.font = BOLD_FONT if col_idx == 4 else REGULAR_FONT
            c.alignment = Alignment(horizontal="center", vertical="center")
            c.border = THIN_BORDER
            if row_idx % 2 == 1:
                c.fill = ALT_FILL
    auto_fit_columns(ws3)

    # -------------------------------------------------------------
    # Sheet 4: Baseline Comparison
    # -------------------------------------------------------------
    ws4 = wb.create_sheet(title="Baseline Comparison")
    ws4["A1"] = "COMPARATIVE ANALYSIS: PROPOSED VS BASELINE MODELS"
    ws4["A1"].font = TITLE_FONT
    
    headers4 = ["Model Architecture", "Accuracy (%)", "Precision (%)", "Recall (%)", "F1-Score (%)", "ROC-AUC", "FPR (%)", "FNR (%)"]
    ws4.append([])
    ws4.append(headers4)
    for col_num in range(1, len(headers4) + 1):
        apply_header_style(ws4.cell(row=3, column=col_num))
        
    for r_idx, row in baseline_df.iterrows():
        row_data = [
            row["Model"],
            f"{row['Accuracy']:.2f}%",
            f"{row['Precision']:.2f}%",
            f"{row['Recall']:.2f}%",
            f"{row['F1_Score']:.2f}%",
            f"{row['ROC_AUC']:.4f}",
            f"{row['FPR']:.4f}%",
            f"{row['FNR']:.4f}%"
        ]
        ws4.append(row_data)
        current_row = ws4.max_row
        is_proposed = "Proposed" in str(row["Model"])
        for c_idx in range(1, len(row_data) + 1):
            c = ws4.cell(row=current_row, column=c_idx)
            c.font = BOLD_FONT if is_proposed else REGULAR_FONT
            c.alignment = Alignment(horizontal="center", vertical="center")
            c.border = THIN_BORDER
            if is_proposed:
                c.fill = SUCCESS_FILL
            elif current_row % 2 == 1:
                c.fill = ALT_FILL
    auto_fit_columns(ws4)

    # -------------------------------------------------------------
    # Sheet 5: Ablation Study
    # -------------------------------------------------------------
    ws5 = wb.create_sheet(title="Ablation Study")
    ws5["A1"] = "ARCHITECTURAL ABLATION STUDY"
    ws5["A1"].font = TITLE_FONT
    
    headers5 = ["Ablation Configuration", "Removed Component", "Accuracy (%)", "Precision (%)", "Recall (%)", "F1-Score (%)", "Δ F1 vs Proposed (%)"]
    ws5.append([])
    ws5.append(headers5)
    for col_num in range(1, len(headers5) + 1):
        apply_header_style(ws5.cell(row=3, column=col_num))
        
    for r_idx, row in ablation_df.iterrows():
        row_data = [
            row["Configuration"],
            row["Removed_Component"],
            f"{row['Accuracy']:.2f}%",
            f"{row['Precision']:.2f}%",
            f"{row['Recall']:.2f}%",
            f"{row['F1_Score']:.2f}%",
            f"{row['Delta_F1']:.2f}%"
        ]
        ws5.append(row_data)
        current_row = ws5.max_row
        is_full = "Proposed" in str(row["Configuration"])
        for c_idx in range(1, len(row_data) + 1):
            c = ws5.cell(row=current_row, column=c_idx)
            c.font = BOLD_FONT if is_full else REGULAR_FONT
            c.alignment = Alignment(horizontal="center", vertical="center")
            c.border = THIN_BORDER
            if is_full:
                c.fill = SUCCESS_FILL
            elif current_row % 2 == 1:
                c.fill = ALT_FILL
    auto_fit_columns(ws5)

    # -------------------------------------------------------------
    # Sheet 6: Computational Efficiency
    # -------------------------------------------------------------
    ws6 = wb.create_sheet(title="Computational Efficiency")
    ws6["A1"] = "COMPUTATIONAL COMPLEXITY & EFFICIENCY ANALYSIS"
    ws6["A1"].font = TITLE_FONT
    
    headers6 = ["Model", "Parameters", "Model Size (MB)", "Training Time (s)", "Epoch Time (s)", "Inference Latency (ms/sample)", "Throughput (samples/s)"]
    ws6.append([])
    ws6.append(headers6)
    for col_num in range(1, len(headers6) + 1):
        apply_header_style(ws6.cell(row=3, column=col_num))
        
    for r_idx, row in efficiency_df.iterrows():
        row_data = [
            row["Model"],
            f"{row['Parameters']:,}" if isinstance(row['Parameters'], (int, float)) else str(row['Parameters']),
            f"{row['Model_Size_MB']:.3f}" if isinstance(row['Model_Size_MB'], (int, float)) else str(row['Model_Size_MB']),
            f"{row['Training_Time_s']:.2f}",
            f"{row['Epoch_Time_s']:.3f}" if isinstance(row['Epoch_Time_s'], (int, float)) else str(row['Epoch_Time_s']),
            f"{row['Latency_ms']:.4f}",
            f"{1000.0 / row['Latency_ms']:.1f}" if row['Latency_ms'] > 0 else "N/A"
        ]
        ws6.append(row_data)
        current_row = ws6.max_row
        is_proposed = "Proposed" in str(row["Model"])
        for c_idx in range(1, len(row_data) + 1):
            c = ws6.cell(row=current_row, column=c_idx)
            c.font = BOLD_FONT if is_proposed else REGULAR_FONT
            c.alignment = Alignment(horizontal="center", vertical="center")
            c.border = THIN_BORDER
            if is_proposed:
                c.fill = SUCCESS_FILL
            elif current_row % 2 == 1:
                c.fill = ALT_FILL
    auto_fit_columns(ws6)

    # -------------------------------------------------------------
    # Sheet 7: PAM & Secure Transfer Log
    # -------------------------------------------------------------
    ws7 = wb.create_sheet(title="PAM & Secure Transfer Log")
    ws7["A1"] = "PRIVILEGE ACCESS MANAGEMENT (PAM) & SECURE TRANSFER AUDIT LOG"
    ws7["A1"].font = TITLE_FONT
    
    headers7 = ["Timestamp", "Client ID", "Role", "Clearance", "Resource", "Risk Score", "Threshold", "Alert", "Decision", "Status", "Transfer Status", "Encryption Latency (ms)", "Integrity Verified"]
    ws7.append([])
    ws7.append(headers7)
    for col_num in range(1, len(headers7) + 1):
        apply_header_style(ws7.cell(row=3, column=col_num))
        
    for r in pam_records:
        row_data = [
            r["timestamp"],
            r["user_id"],
            r["role"],
            r["clearance_level"],
            r["resource"],
            r["phishing_risk_score"],
            r["threshold"],
            r["alert_signal"],
            r["decision"],
            r["status"],
            r["transfer_status"],
            r["encryption_latency_ms"],
            "YES" if r["integrity_verified"] else "NO"
        ]
        ws7.append(row_data)
        current_row = ws7.max_row
        is_denied = r["status"] != "ACCESS_GRANTED"
        for c_idx in range(1, len(row_data) + 1):
            c = ws7.cell(row=current_row, column=c_idx)
            c.font = REGULAR_FONT
            c.alignment = Alignment(horizontal="center", vertical="center")
            c.border = THIN_BORDER
            if is_denied:
                c.fill = DANGER_FILL
            else:
                c.fill = SUCCESS_FILL
    auto_fit_columns(ws7)
    
    # Save Workbook
    wb.save(EXCEL_PATH)
    print(f"      Excel report successfully exported: {EXCEL_PATH}")
    return EXCEL_PATH
