import numpy as np
import pandas as pd
from sklearn.feature_selection import RFE
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression
from config import NUM_SELECTED_FEATURES, RANDOM_SEED

def perform_rfe_selection(X_train, y_train, X_val, X_test, n_features_to_select=NUM_SELECTED_FEATURES):
    """
    Executes Recursive Feature Elimination (RFE) to:
    1. Identify the most discriminative website and URL features
    2. Rank all features from 1 (highest importance) to lowest
    3. Eliminate redundant and noisy features
    4. Transform X_train, X_val, X_test to the optimal selected subset
    """
    print(f"[2/7] Executing Recursive Feature Elimination (RFE) to select top {n_features_to_select} features...")
    
    # Use an ensemble estimator on a stratified subsample for rapid, robust feature ranking
    estimator = ExtraTreesClassifier(n_estimators=50, random_state=RANDOM_SEED, n_jobs=-1, max_depth=12)
    
    # Fit RFE selector
    rfe = RFE(
        estimator=estimator,
        n_features_to_select=n_features_to_select,
        step=4,
        verbose=0
    )
    
    # Use subsample for feature ranking stability
    subsample_size = min(20000, len(X_train))
    sub_indices = np.random.RandomState(RANDOM_SEED).choice(len(X_train), subsample_size, replace=False)
    X_sub = X_train.iloc[sub_indices]
    y_sub = y_train[sub_indices]
    
    rfe.fit(X_sub, y_sub)
    
    feature_names = X_train.columns.tolist()
    support = rfe.support_
    ranking = rfe.ranking_
    
    # Get feature importance from the estimator for the selected features
    importances = np.zeros(len(feature_names))
    if hasattr(rfe.estimator_, "feature_importances_"):
        importances[support] = rfe.estimator_.feature_importances_
    
    rfe_df = pd.DataFrame({
        "Feature": feature_names,
        "Rank": ranking,
        "Selected": support,
        "Importance": importances
    }).sort_values(by=["Rank", "Importance"], ascending=[True, False]).reset_index(drop=True)
    
    selected_features = rfe_df[rfe_df["Selected"]]["Feature"].tolist()
    print(f"      RFE completed! Selected {len(selected_features)} features.")
    print(f"      Top 10 selected features: {selected_features[:10]}")
    
    # Transform train, val, test datasets
    X_train_rfe = X_train[selected_features].copy()
    X_val_rfe = X_val[selected_features].copy()
    X_test_rfe = X_test[selected_features].copy()
    
    return {
        "selected_features": selected_features,
        "rfe_df": rfe_df,
        "X_train_rfe": X_train_rfe,
        "X_val_rfe": X_val_rfe,
        "X_test_rfe": X_test_rfe,
        "rfe_model": rfe
    }

if __name__ == "__main__":
    from data_preprocessing import load_and_preprocess_data
    data = load_and_preprocess_data()
    rfe_res = perform_rfe_selection(data["X_train"], data["y_train"], data["X_val"], data["X_test"])
    print("RFE selection tested successfully!")
