import zipfile
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from config import DATA_PATH, RANDOM_SEED

def load_and_preprocess_data():
    """
    Loads dataset_full.csv from archive.zip and performs:
    1. Missing-value handling
    2. Duplicate removal
    3. Label encoding
    4. Website & URL characteristic feature extraction
    5. Feature normalization
    6. Stratified train/val/test splitting
    """
    print("[1/7] Loading dataset from archive.zip...")
    with zipfile.ZipFile(DATA_PATH) as z:
        with z.open("dataset_full.csv") as f:
            df = pd.read_csv(f)

    initial_samples = len(df)
    initial_features = df.shape[1] - 1
    print(f"      Initial dataset: {initial_samples:,} records, {initial_features} features.")

    # 1. Missing-value handling
    missing_count = df.isnull().sum().sum()
    if missing_count > 0:
        df = df.fillna(df.median(numeric_only=True))
    print(f"      Missing values identified & handled: {missing_count}")

    # 2. Duplicate removal
    duplicate_count = df.duplicated().sum()
    df = df.drop_duplicates().reset_index(drop=True)
    cleaned_samples = len(df)
    print(f"      Duplicates removed: {duplicate_count:,} (Remaining records: {cleaned_samples:,})")

    # 3. Target Label Verification & Encoding
    # Ensure binary: 0 = Legitimate, 1 = Phishing
    target_col = "phishing"
    df[target_col] = df[target_col].astype(int)
    class_counts = df[target_col].value_counts().to_dict()
    legitimate_count = class_counts.get(0, 0)
    phishing_count = class_counts.get(1, 0)
    print(f"      Class distribution: Legitimate (0)={legitimate_count:,} ({legitimate_count/cleaned_samples:.2%}), Phishing (1)={phishing_count:,} ({phishing_count/cleaned_samples:.2%})")

    # 4. Website-related Feature Extraction (URL & Webpage Characteristics)
    # Extract domain/URL structural complexity, delimiter density, and parameter entropy
    print("      Extracting website & URL characteristics...")
    df["url_delimiter_ratio"] = (df["qty_slash_url"] + df["qty_dot_url"] + df["qty_hyphen_url"] + df["qty_underline_url"]) / (df["length_url"] + 1.0)
    df["domain_vowel_ratio"] = df["qty_vowels_domain"] / (df["domain_length"] + 1.0)
    df["param_density"] = df["qty_params"] / (df["params_length"].clip(lower=0) + 1.0)
    df["suspicious_token_score"] = df["domain_in_ip"] + df["server_client_domain"] + df["email_in_url"] + df["url_shortened"]
    df["dir_to_url_ratio"] = df["directory_length"].clip(lower=0) / (df["length_url"] + 1.0)

    # Replace any infinite or NaN values arising from ratio divisions
    df = df.replace([np.inf, -np.inf], 0.0)
    df = df.fillna(0.0)

    # Separate Features and Target
    feature_cols = [c for c in df.columns if c != target_col]
    X = df[feature_cols].copy()
    y = df[target_col].values

    # 5. Stratified Train / Validation / Test Splitting (70% Train, 10% Val, 20% Test)
    X_train_raw, X_test_raw, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=RANDOM_SEED, stratify=y
    )
    X_train_sub, X_val_raw, y_train_sub, y_val = train_test_split(
        X_train_raw, y_train, test_size=0.125, random_state=RANDOM_SEED, stratify=y_train
    )  # 0.125 * 0.80 = 0.10 val, 0.70 train

    # 6. Feature Normalization (StandardScaler fitted strictly on training data)
    scaler = StandardScaler()
    X_train_scaled = pd.DataFrame(scaler.fit_transform(X_train_sub), columns=feature_cols, index=X_train_sub.index)
    X_val_scaled = pd.DataFrame(scaler.transform(X_val_raw), columns=feature_cols, index=X_val_raw.index)
    X_test_scaled = pd.DataFrame(scaler.transform(X_test_raw), columns=feature_cols, index=X_test_raw.index)

    distribution_info = {
        "initial_samples": initial_samples,
        "duplicates_removed": duplicate_count,
        "clean_samples": cleaned_samples,
        "total_features": len(feature_cols),
        "legitimate_total": legitimate_count,
        "phishing_total": phishing_count,
        "train_samples": len(y_train_sub),
        "val_samples": len(y_val),
        "test_samples": len(y_test),
        "train_legitimate": int((y_train_sub == 0).sum()),
        "train_phishing": int((y_train_sub == 1).sum()),
        "val_legitimate": int((y_val == 0).sum()),
        "val_phishing": int((y_val == 1).sum()),
        "test_legitimate": int((y_test == 0).sum()),
        "test_phishing": int((y_test == 1).sum())
    }

    print(f"      Splits prepared: Train={len(y_train_sub):,}, Val={len(y_val):,}, Test={len(y_test):,}")

    return {
        "df_clean": df,
        "feature_cols": feature_cols,
        "X_train": X_train_scaled,
        "X_val": X_val_scaled,
        "X_test": X_test_scaled,
        "y_train": y_train_sub,
        "y_val": y_val,
        "y_test": y_test,
        "scaler": scaler,
        "distribution_info": distribution_info
    }

if __name__ == "__main__":
    data = load_and_preprocess_data()
    print("Data loading & preprocessing tested successfully!")
