import os
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from config import FIGURES_DIR, DPI, FIGSIZE, FONT_FAMILY, FONT_SIZE, FONT_WEIGHT, COLORS, set_plot_style

def setup_fig_ax():
    """Applies strict formatting and returns fig, ax with no grids."""
    set_plot_style()
    fig, ax = plt.subplots(figsize=FIGSIZE)
    ax.grid(False)
    # Ensure spines are bold and clean
    for spine in ax.spines.values():
        spine.set_linewidth(1.8)
        spine.set_color("#1F2937")
    return fig, ax


def save_fig(fig, filename):
    """Saves the figure at 800 DPI without grids and tight layout."""
    filepath = os.path.join(FIGURES_DIR, filename)
    fig.savefig(filepath, dpi=DPI, bbox_inches="tight")
    plt.close(fig)
    print(f"      Figure saved: {filename} (dpi={DPI}, size={FIGSIZE})")
    return filepath


def plot_dataset_distribution(dist_info):
    """Figure 1: Dataset class distribution across Train, Val, and Test splits."""
    fig, ax = setup_fig_ax()
    
    categories = ["Train\nPartition", "Validation\nPartition", "Test\nPartition", "Total Clean\nDataset"]
    legit_vals = [
        dist_info["train_legitimate"],
        dist_info["val_legitimate"],
        dist_info["test_legitimate"],
        dist_info["legitimate_total"]
    ]
    phish_vals = [
        dist_info["train_phishing"],
        dist_info["val_phishing"],
        dist_info["test_phishing"],
        dist_info["phishing_total"]
    ]
    
    x = np.arange(len(categories))
    width = 0.35
    
    rects1 = ax.bar(x - width/2, legit_vals, width, label="Legitimate", color=COLORS["legitimate"], edgecolor="black", linewidth=1.2)
    rects2 = ax.bar(x + width/2, phish_vals, width, label="Phishing", color=COLORS["phishing"], edgecolor="black", linewidth=1.2)
    
    ax.set_xlabel("Dataset Partitions", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=12)
    ax.set_ylabel("Number of Samples", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=10)
    ax.set_title("Dataset Distribution by Split & Class", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE + 2, pad=15)
    ax.set_xticks(x)
    ax.set_xticklabels(categories, fontweight=FONT_WEIGHT, fontsize=FONT_SIZE - 2, rotation=0)
    ax.legend(frameon=False)
    
    # Add counts on top of bars
    for rect in rects1 + rects2:
        height = rect.get_height()
        ax.annotate(f"{height:,}",
                    xy=(rect.get_x() + rect.get_width() / 2, height),
                    xytext=(0, 3), textcoords="offset points",
                    ha="center", va="bottom", fontsize=FONT_SIZE - 4, fontweight=FONT_WEIGHT)
        
    save_fig(fig, "01_dataset_distribution.png")


def plot_rfe_feature_importance(rfe_df, top_n=20):
    """Figure 2: Top Selected Features by RFE Ranking & Importance."""
    fig, ax = setup_fig_ax()
    
    top_df = rfe_df.head(top_n).sort_values(by="Importance", ascending=True)
    y_pos = np.arange(len(top_df))
    
    bars = ax.barh(y_pos, top_df["Importance"], color=COLORS["secondary"], edgecolor="black", linewidth=1.2)
    ax.set_yticks(y_pos)
    ax.set_yticklabels(top_df["Feature"], fontweight=FONT_WEIGHT, fontsize=FONT_SIZE - 4)
    ax.set_xlabel("Relative Feature Importance Score", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=12)
    ax.set_ylabel("Selected Salient Features", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=10)
    ax.set_title(f"Top {top_n} Salient Features Selected by RFE", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE + 2, pad=15)
    
    save_fig(fig, "02_rfe_feature_importance.png")


def plot_training_validation_accuracy(history):
    """Figure 3: Training and Validation Accuracy Curves."""
    fig, ax = setup_fig_ax()
    epochs = range(1, len(history["train_acc"]) + 1)
    
    ax.plot(epochs, [a * 100 for a in history["train_acc"]], color=COLORS["primary"], linewidth=2.8, label="Training Accuracy")
    ax.plot(epochs, [a * 100 for a in history["val_acc"]], color=COLORS["warning"], linewidth=2.8, linestyle="--", label="Validation Accuracy")
    
    ax.set_xlabel("Training Epochs", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=12)
    ax.set_ylabel("Accuracy (%)", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=10)
    ax.set_title("Training and Validation Accuracy Curves", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE + 2, pad=15)
    ax.legend(frameon=False, loc="lower right")
    ax.set_ylim(85, 100)
    
    save_fig(fig, "03_training_validation_accuracy.png")


def plot_training_validation_loss(history):
    """Figure 4: Training and Validation Loss Curves."""
    fig, ax = setup_fig_ax()
    epochs = range(1, len(history["train_loss"]) + 1)
    
    ax.plot(epochs, history["train_loss"], color=COLORS["primary"], linewidth=2.8, label="Training Loss")
    ax.plot(epochs, history["val_loss"], color=COLORS["warning"], linewidth=2.8, linestyle="--", label="Validation Loss")
    
    ax.set_xlabel("Training Epochs", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=12)
    ax.set_ylabel("Cross-Entropy Loss", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=10)
    ax.set_title("Training and Validation Loss Curves", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE + 2, pad=15)
    ax.legend(frameon=False, loc="upper right")
    
    save_fig(fig, "04_training_validation_loss.png")


def plot_confusion_matrix(cm):
    """Figure 5: High-resolution Confusion Matrix."""
    fig, ax = setup_fig_ax()
    
    labels = ["Legitimate", "Phishing"]
    sns.heatmap(cm, annot=True, fmt=",d", cmap="Blues", cbar=True,
                xticklabels=labels, yticklabels=labels, ax=ax,
                annot_kws={"size": FONT_SIZE + 2, "weight": FONT_WEIGHT})
    
    ax.set_xlabel("Predicted Class Label", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=12)
    ax.set_ylabel("Actual Class Label", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=10)
    ax.set_xticklabels(labels, fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, rotation=0)
    ax.set_yticklabels(labels, fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, rotation=0)
    ax.set_title("Confusion Matrix of Proposed Hybrid Model", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE + 2, pad=15)
    
    save_fig(fig, "05_confusion_matrix.png")


def plot_roc_curve(fpr, tpr, auc_val):
    """Figure 6: ROC Curve with AUC and Optimal Operating Point."""
    fig, ax = setup_fig_ax()
    
    ax.plot(fpr, tpr, color=COLORS["warning"], linewidth=3.0, label=f"Proposed Model (AUC = {auc_val:.4f})")
    ax.plot([0, 1], [0, 1], color="#9CA3AF", linewidth=2.0, linestyle="--", label="Random Baseline (AUC = 0.5000)")
    
    # Identify optimal operating point (maximum Youden's J statistic)
    j_scores = tpr - fpr
    opt_idx = np.argmax(j_scores)
    ax.scatter(fpr[opt_idx], tpr[opt_idx], color=COLORS["accent"], s=160, zorder=5,
               label=f"Optimal Threshold (FPR={fpr[opt_idx]:.3f}, TPR={tpr[opt_idx]:.3f})")
    
    ax.set_xlabel("False Positive Rate (FPR)", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=12)
    ax.set_ylabel("True Positive Rate (TPR)", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=10)
    ax.set_title("Receiver Operating Characteristic (ROC) Curve", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE + 2, pad=15)
    ax.legend(frameon=False, loc="lower right")
    ax.set_xlim([-0.02, 1.02])
    ax.set_ylim([-0.02, 1.02])
    
    save_fig(fig, "06_roc_curve.png")


def plot_precision_recall_curve(precision, recall, avg_prec):
    """Figure 7: Precision-Recall Curve with Best Balance Marker."""
    fig, ax = setup_fig_ax()
    
    ax.plot(recall, precision, color=COLORS["legitimate"], linewidth=3.0, label=f"PR Curve (AP = {avg_prec:.4f})")
    
    # Highlight max F1 point
    f1_scores = 2 * (precision * recall) / (precision + recall + 1e-10)
    opt_idx = np.argmax(f1_scores)
    ax.scatter(recall[opt_idx], precision[opt_idx], color=COLORS["accent"], s=160, zorder=5,
               label=f"Max F1 Operating Point (Rec={recall[opt_idx]:.3f}, Prec={precision[opt_idx]:.3f})")
    
    ax.set_xlabel("Recall / Sensitivity", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=12)
    ax.set_ylabel("Precision", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=10)
    ax.set_title("Precision–Recall Curve", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE + 2, pad=15)
    ax.legend(frameon=False, loc="lower left")
    ax.set_xlim([-0.02, 1.02])
    ax.set_ylim([0.80, 1.02])
    
    save_fig(fig, "07_precision_recall_curve.png")


def plot_decision_threshold(thresholds, f1_scores, best_thresh):
    """Figure 8: Decision Threshold Optimization Curve."""
    fig, ax = setup_fig_ax()
    
    ax.plot(thresholds, f1_scores, color=COLORS["success"], linewidth=3.0, label="F1-Score vs Threshold")
    
    best_idx = np.argmax(f1_scores)
    best_f1 = f1_scores[best_idx]
    ax.scatter(best_thresh, best_f1, color=COLORS["accent"], s=160, zorder=5,
               label=f"Optimal Decision Threshold (T = {best_thresh:.2f}, F1 = {best_f1:.4f})")
    
    ax.set_xlabel("Decision Threshold (T)", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=12)
    ax.set_ylabel("F1-Score / Performance Score", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=10)
    ax.set_title("Performance Trade-off Across Decision Thresholds", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE + 2, pad=15)
    ax.legend(frameon=False, loc="lower center")
    
    save_fig(fig, "08_decision_threshold.png")


def plot_performance_metrics_bar(metrics):
    """Figure 9: Comprehensive Performance Metrics Bar Chart."""
    fig, ax = setup_fig_ax()
    
    metric_names = ["Accuracy", "Precision", "Sensitivity", "Specificity", "F-Measure", "NPV"]
    values = [
        metrics["accuracy"] * 100,
        metrics["precision"] * 100,
        metrics["sensitivity"] * 100,
        metrics["specificity"] * 100,
        metrics["f1_score"] * 100,
        metrics["npv"] * 100
    ]
    
    palette = [COLORS["primary"], COLORS["secondary"], COLORS["success"], COLORS["warning"], COLORS["purple"], "#0284C7"]
    bars = ax.bar(metric_names, values, color=palette, edgecolor="black", linewidth=1.2, width=0.55)
    
    ax.set_xlabel("Performance Evaluation Metrics", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=12)
    ax.set_ylabel("Percentage (%)", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=10)
    ax.set_title("Performance Evaluation Metrics of Proposed Framework", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE + 2, pad=15)
    ax.set_xticks(range(len(metric_names)))
    ax.set_xticklabels(metric_names, fontweight=FONT_WEIGHT, fontsize=FONT_SIZE - 2, rotation=0)
    ax.set_ylim(90, 101)
    
    for bar in bars:
        height = bar.get_height()
        ax.annotate(f"{height:.2f}%",
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 4), textcoords="offset points",
                    ha="center", va="bottom", fontsize=FONT_SIZE - 3, fontweight=FONT_WEIGHT)
        
    save_fig(fig, "09_performance_metrics_bar.png")


def plot_error_rates_fpr_fnr(metrics):
    """Figure 10: False Positive Rate (FPR) and False Negative Rate (FNR)."""
    fig, ax = setup_fig_ax()
    
    err_names = ["False Positive Rate\n(FPR)", "False Negative Rate\n(FNR)"]
    err_values = [metrics["fpr"] * 100, metrics["fnr"] * 100]
    palette = [COLORS["accent"], COLORS["warning"]]
    
    bars = ax.bar(range(len(err_names)), err_values, color=palette, edgecolor="black", linewidth=1.2, width=0.45)
    ax.set_xlabel("Classification Error Metrics", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=12)
    ax.set_ylabel("Error Rate (%)", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=10)
    ax.set_title("Classification Error Analysis: FPR and FNR", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE + 2, pad=15)
    ax.set_xticks(range(len(err_names)))
    ax.set_xticklabels(err_names, fontweight=FONT_WEIGHT, fontsize=FONT_SIZE - 1, rotation=0)
    ax.set_ylim(0, max(err_values) * 1.5 + 0.5)
    
    for bar in bars:
        height = bar.get_height()
        ax.annotate(f"{height:.4f}%",
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 4), textcoords="offset points",
                    ha="center", va="bottom", fontsize=FONT_SIZE - 2, fontweight=FONT_WEIGHT)
        
    save_fig(fig, "10_error_rates_fpr_fnr.png")


def plot_baseline_comparison(comparison_df):
    """Figure 11: Comparative Analysis Across Deep and Classical Baselines."""
    fig, ax = setup_fig_ax()
    
    # Clean, wrapped labels without rotation
    label_mapping = {
        "CNN": "CNN",
        "BiRNN": "BiRNN",
        "CNN-BiRNN": "CNN-\nBiRNN",
        "RFE + CNN-BiRNN": "RFE +\nCNN-BiRNN",
        "Random Forest": "Random\nForest",
        "AdaBoost": "AdaBoost",
        "J48-C": "J48-C",
        "Proposed (RFE + ANN-LSTM + CNN + BiRNN)": "Proposed\nHybrid"
    }
    
    raw_models = comparison_df["Model"].tolist()
    wrapped_models = [label_mapping.get(m, m.replace(" ", "\n")) for m in raw_models]
    
    x = np.arange(len(wrapped_models))
    width = 0.20
    
    metrics = ["Accuracy", "Precision", "Recall", "F1_Score"]
    metric_colors = [COLORS["primary"], COLORS["secondary"], COLORS["success"], COLORS["warning"]]
    
    for i, metric in enumerate(metrics):
        vals = comparison_df[metric].values
        ax.bar(x + (i - 1.5) * width, vals, width, label=metric.replace("_", " "),
               color=metric_colors[i], edgecolor="black", linewidth=1.0)
        
    ax.set_xlabel("Phishing Detection Architectures", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=12)
    ax.set_ylabel("Percentage (%)", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=10)
    ax.set_title("Comparative Evaluation of Proposed vs. Baseline Architectures", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE + 2, pad=15)
    ax.set_xticks(x)
    ax.set_xticklabels(wrapped_models, rotation=0, ha="center", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE - 5)
    ax.legend(frameon=False, loc="lower right")
    ax.set_ylim(85, 102)
    
    save_fig(fig, "11_baseline_comparison.png")


def plot_ablation_study(ablation_df):
    """Figure 12: Architectural Ablation Study."""
    fig, ax = setup_fig_ax()
    
    # Clean, wrapped labels without rotation
    label_mapping = {
        "Proposed Hybrid (Full)": "Proposed\n(Full)",
        "Proposed w/o RFE": "w/o RFE",
        "Proposed w/o ANN-LSTM": "w/o ANN-\nLSTM",
        "Proposed w/o CNN": "w/o CNN",
        "Proposed w/o BiRNN": "w/o BiRNN"
    }
    
    raw_variants = ablation_df["Configuration"].tolist()
    wrapped_variants = [label_mapping.get(v, v.replace(" ", "\n")) for v in raw_variants]
    
    x = np.arange(len(wrapped_variants))
    width = 0.22
    
    metrics = ["Accuracy", "Precision", "F1_Score"]
    metric_colors = [COLORS["primary"], COLORS["purple"], COLORS["secondary"]]
    
    for i, metric in enumerate(metrics):
        vals = ablation_df[metric].values
        ax.bar(x + (i - 1) * width, vals, width, label=metric.replace("_", " "),
               color=metric_colors[i], edgecolor="black", linewidth=1.0)
        
    ax.set_xlabel("Ablation Architectural Variants", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=12)
    ax.set_ylabel("Percentage (%)", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=10)
    ax.set_title("Ablation Study: Component Impact on Detection Performance", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE + 2, pad=15)
    ax.set_xticks(x)
    ax.set_xticklabels(wrapped_variants, rotation=0, ha="center", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE - 3)
    ax.legend(frameon=False, loc="lower right")
    ax.set_ylim(88, 101)
    
    save_fig(fig, "12_ablation_study.png")


def plot_computational_efficiency(efficiency_df):
    """Figure 13: Computational Efficiency Analysis (Inference Latency & Model Size)."""
    fig, ax1 = setup_fig_ax()
    
    # Clean, wrapped labels without rotation
    label_mapping = {
        "CNN": "CNN",
        "BiRNN": "BiRNN",
        "CNN-BiRNN": "CNN-\nBiRNN",
        "RFE + CNN-BiRNN": "RFE +\nCNN-BiRNN",
        "Proposed Hybrid (Full)": "Proposed\nHybrid"
    }
    
    raw_models = efficiency_df["Model"].tolist()
    wrapped_models = [label_mapping.get(m, m.replace(" ", "\n")) for m in raw_models]
    
    x = np.arange(len(wrapped_models))
    width = 0.35
    
    # Latency (ms)
    color1 = COLORS["primary"]
    rects1 = ax1.bar(x - width/2, efficiency_df["Latency_ms"], width, label="Inference Latency (ms/sample)",
                     color=color1, edgecolor="black", linewidth=1.2)
    ax1.set_xlabel("Evaluated Deep Learning Architectures", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=12)
    ax1.set_ylabel("Inference Latency (ms)", color=color1, fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=10)
    ax1.tick_params(axis="y", labelcolor=color1)
    
    # Second y-axis for Training Time
    ax2 = ax1.twinx()
    ax2.grid(False)
    for spine in ax2.spines.values():
        spine.set_linewidth(1.8)
    color2 = COLORS["accent"]
    rects2 = ax2.bar(x + width/2, efficiency_df["Training_Time_s"], width, label="Training Time (s)",
                     color=color2, edgecolor="black", linewidth=1.2)
    ax2.set_ylabel("Total Training Time (s)", color=color2, fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=10)
    ax2.tick_params(axis="y", labelcolor=color2)
    
    ax1.set_xticks(x)
    ax1.set_xticklabels(wrapped_models, rotation=0, ha="center", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE - 3)
    ax1.set_title("Computational Efficiency: Latency vs. Training Cost", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE + 2, pad=15)
    
    save_fig(fig, "13_computational_efficiency.png")


def plot_pam_secure_transfer_simulation(pam_log):
    """Figure 14: Privilege Access Management & Secure Transfer Security Metrics."""
    fig, ax = setup_fig_ax()
    
    decision_mapping = {
        "APPROVED_SECURE_TRANSFER": "Approved\nSecure Transfer",
        "BLOCKED_PHISHING_ATTACK": "Blocked\nPhishing Threat",
        "BLOCKED_INSUFFICIENT_PRIVILEGE": "Blocked\nPrivilege Limit",
        "BLOCKED_UNAUTHORIZED_ROLE": "Blocked\nUnauthorized"
    }
    
    raw_decisions = [e["decision"] for e in pam_log]
    unique_decisions, counts = np.unique(raw_decisions, return_counts=True)
    wrapped_labels = [decision_mapping.get(d, d.replace("_", "\n")) for d in unique_decisions]
    
    colors = [COLORS["success"] if "APPROVED" in d else COLORS["accent"] for d in unique_decisions]
    bars = ax.bar(range(len(wrapped_labels)), counts, color=colors, edgecolor="black", linewidth=1.2, width=0.45)
    
    ax.set_xlabel("Access Control Decisions", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=12)
    ax.set_ylabel("Transaction Count", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE, labelpad=10)
    ax.set_title("Privilege Access Management (PAM) Security Enforcement", fontweight=FONT_WEIGHT, fontsize=FONT_SIZE + 2, pad=15)
    ax.set_xticks(range(len(wrapped_labels)))
    ax.set_xticklabels(wrapped_labels, fontweight=FONT_WEIGHT, fontsize=FONT_SIZE - 3, rotation=0)
    
    for bar in bars:
        height = bar.get_height()
        ax.annotate(f"{height}",
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 4), textcoords="offset points",
                    ha="center", va="bottom", fontsize=FONT_SIZE - 2, fontweight=FONT_WEIGHT)
        
    save_fig(fig, "14_pam_secure_transfer_simulation.png")
